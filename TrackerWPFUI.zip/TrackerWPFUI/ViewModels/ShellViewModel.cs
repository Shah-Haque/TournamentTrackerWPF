﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLibrary;
using TrackerLibrary.Models;
using TrackerWPFUI.Views;

//44:12
namespace TrackerWPFUI.ViewModels
{
    public class ShellViewModel : Conductor<object>, IHandle<TournamentModel>
    {  
        private BindableCollection<TournamentModel> _ExistingTournaments;
        private TournamentModel _SelectedTournament;

        public ShellViewModel()
        {
            //Initialize Database connection
            TrackerLibrary.GlobalConfig.InitializeConnections(DatabaseType.sql);

            EventAggregationProvider.TournamentTrackerEventAggregator.Subscribe(this);

            _ExistingTournaments = new BindableCollection<TournamentModel>(GlobalConfig.Connection.GetTournament_All());
        }

        public void CreateTournament()
        {
            ActivateItem(new CreateTournamentViewModel());
        }

        public void LoadTournament()
        {
            if (SelectedTournament != null && !String.IsNullOrWhiteSpace(SelectedTournament.TournamentName))
            {
                ActivateItem(new TournamentViewerViewModel(SelectedTournament));
            }
        }

        public void Handle(TournamentModel message)
        {
            //open the tournament viewer form to the given tournament
            ExistingTournaments.Add(message);
            SelectedTournament = message;
       
        }

        public BindableCollection<TournamentModel> ExistingTournaments
        {
            get { return _ExistingTournaments; }
            set { _ExistingTournaments = value; }
        }

        public TournamentModel SelectedTournament
        {
            get { return _SelectedTournament; }
            set
            {
                _SelectedTournament = value;
                NotifyOfPropertyChange(() => SelectedTournament);
                LoadTournament();

            }
        }

    }
}

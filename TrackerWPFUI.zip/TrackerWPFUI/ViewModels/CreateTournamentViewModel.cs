﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TrackerWPFUI.ViewModels
{
    public class CreateTournamentViewModel : Conductor<object>.Collection.AllActive, IHandle<TeamModel>, IHandle<PrizeModel>
    {
		/// <summary>
		/// Tournament Variables
		/// </summary>
		private string _TournamentName = "";
		private decimal _EntryFee;

		/// <summary>
		/// Teams Variables
		/// </summary>
		private BindableCollection<TeamModel> _AvailableTeams;
		private TeamModel _SelectedTeamToAdd;
		private BindableCollection<TeamModel> _SelectedTeams = new BindableCollection<TeamModel>();
		private TeamModel _SelectedTeamToRemove;
		private Screen _ActiveAddTeamView;
		private bool _SelectedTeamIsVisible = true;
		private bool _AddTeamIsVisible = false;

		/// <summary>
		///Prizes Variables
		/// </summary>
		private BindableCollection<PrizeModel> _SelectedPrizes = new BindableCollection<PrizeModel>();
		private PrizeModel _SelectedPrizeToRemove;
		private Screen _ActiveAddPrizeView;
		private bool _SelectedPrizeIsVisible = true;
		private bool _AddPrizeIsVisible = false;

        public CreateTournamentViewModel()
        {
			AvailableTeams = new BindableCollection<TeamModel>(GlobalConfig.Connection.GetTeam_All());
			EventAggregationProvider.TournamentTrackerEventAggregator.Subscribe(this);
        }
  
        public string TournamentName
		{
			get { return _TournamentName; }
			set
			{ 
				_TournamentName = value;
				NotifyOfPropertyChange(() => TournamentName);
				NotifyOfPropertyChange(() => CanCreateTournament);

			}
		}
		
		public decimal EntryFee
		{
			get { return _EntryFee; }
			set 
			{ 
				_EntryFee = value;
				NotifyOfPropertyChange(() => EntryFee);
			}
		}

		public BindableCollection<TeamModel> AvailableTeams
		{
			get { return _AvailableTeams; }
			set { _AvailableTeams = value;}
		}

		public TeamModel SelectedTeamToAdd
		{
			get { return _SelectedTeamToAdd; }
			set
			{
				_SelectedTeamToAdd = value;
                NotifyOfPropertyChange(() => SelectedTeamToAdd);
				NotifyOfPropertyChange(() => canAddTeam);
            }
		}

        public BindableCollection<TeamModel> SelectedTeams
        {
            get { return _SelectedTeams; }
            set 
			{ 
				_SelectedTeams = value;
                NotifyOfPropertyChange(() => SelectedTeams);
                NotifyOfPropertyChange(() => CanCreateTournament);
            }
        }
		
        public TeamModel SelectedTeamToRemove
        {
            get { return _SelectedTeamToRemove; }
            set
            {
                _SelectedTeamToRemove = value;
                NotifyOfPropertyChange(() => SelectedTeamToRemove);
				NotifyOfPropertyChange(() => CanRemoveTeam);
            }
        }

		public Screen ActiveAddTeamView
		{
			get { return _ActiveAddTeamView; }
			set 
			{
				_ActiveAddTeamView = value; 
				NotifyOfPropertyChange(() => ActiveAddTeamView);
			}
		}

        public BindableCollection<PrizeModel> SelectedPrizes
        {
            get { return _SelectedPrizes; }
            set
            {
                _SelectedPrizes = value;
                NotifyOfPropertyChange(() => SelectedPrizes);
            }
        }

        public PrizeModel SelectedPrizeToRemove
        {
            get { return _SelectedPrizeToRemove; }
            set
            {
                _SelectedPrizeToRemove = value;
                NotifyOfPropertyChange(() => SelectedPrizeToRemove);
				NotifyOfPropertyChange(() => CanRemovePrize);
            }
        }

        public Screen ActiveAddPrizeView
        {
            get { return _ActiveAddPrizeView; }
            set
            {
                _ActiveAddPrizeView = value;
                NotifyOfPropertyChange(() => ActiveAddPrizeView);
            }
        }

		public bool SelectedTeamIsVisible
		{
			get { return _SelectedTeamIsVisible; }
			set 
			{ 
				_SelectedTeamIsVisible = value;
				NotifyOfPropertyChange(() => SelectedTeamIsVisible);
			}
		}

        public bool AddTeamIsVisible
        {
            get { return _AddTeamIsVisible; }
            set
            {
                _AddTeamIsVisible = value;
                NotifyOfPropertyChange(() => AddTeamIsVisible);
            }
        }

        public bool SelectedPrizeIsVisible
        {
            get { return _SelectedPrizeIsVisible; }
            set
            {
                _SelectedPrizeIsVisible = value;
                NotifyOfPropertyChange(() => SelectedPrizeIsVisible);
            }
        }

        public bool AddPrizeIsVisible
        {
            get { return _AddPrizeIsVisible; }
            set
            {
                _AddPrizeIsVisible = value;
                NotifyOfPropertyChange(() => AddPrizeIsVisible);
            }
        }


        public bool canAddTeam
		{
			get
			{
                return SelectedTeamToAdd != null;
            }
		}

		public void AddTeam()
		{
			SelectedTeams.Add(SelectedTeamToAdd);
			AvailableTeams.Remove(SelectedTeamToAdd);
            NotifyOfPropertyChange(() => CanCreateTournament);
        }

		public void CreateTeam()
		{
            ActiveAddTeamView = new CreateTeamViewModel();
			Items.Add(ActiveAddTeamView);

			SelectedTeamIsVisible = false;
			AddTeamIsVisible = true;
		}

		public bool CanRemoveTeam
		{
			get 
			{
                return SelectedTeamToRemove != null;
            }
		}

		public void RemoveTeam()
		{
			AvailableTeams.Add(SelectedTeamToRemove);
			SelectedTeams.Remove(SelectedTeamToRemove);
            NotifyOfPropertyChange(() => CanCreateTournament);
        }

		public void CreatePrize()
		{
			ActiveAddPrizeView = new CreatePrizeViewModel();
			Items.Add(ActiveAddPrizeView);

			SelectedPrizeIsVisible = false;
			AddPrizeIsVisible = true;
		}

		public bool CanRemovePrize
		{
			get
			{
				return SelectedPrizeToRemove != null;
			}
		}

		public void RemovePrize()
		{
			SelectedPrizes.Remove(SelectedPrizeToRemove);
		}

		public bool CanCreateTournament
		{
			get
			{
				if (SelectedTeams != null)
				{
					if (TournamentName.Length > 0 && SelectedTeams.Count > 1)
					{
						return true;
					}
					else
					{
						return false;
					} 
				}
				else
				{
					return false;
				}
			}
		}

		public void CreateTournament()
		{
            // this create a tournament model
            TournamentModel tm = new TournamentModel();

            tm.TournamentName = TournamentName;
            tm.EntryFee = EntryFee;

            // Prizes that are selected from the PrizeModel will be added into the TournamentModel
            tm.Prizes = SelectedPrizes.ToList();
            tm.EnteredTeams = SelectedTeams.ToList();

            //  Wire our matchups
            TournamentLogic.CreateRounds(tm);

            //  Order our list Randomly
            //  Check if it is big enough -  if not, add in byes - 2^2^2^2  -  2^4
            //  Create our First round of matchups
            //  create every round after that  -  8 matchups - 4 matchups -  2 matchups - 1 matchups

            // Creates a tournament entry
            // Creates all of the prizes entries
            // creates all of the team entries
            GlobalConfig.Connection.createTournament(tm);

            tm.AlertUsersToNewRound();

			EventAggregationProvider.TournamentTrackerEventAggregator.PublishOnCurrentThread(tm);
			this.TryClose();
        }

        public void Handle(TeamModel message)
        {
			if (!String.IsNullOrWhiteSpace(message.TeamName))
			{
				SelectedTeams.Add(message);
                NotifyOfPropertyChange(() => CanCreateTournament);
            }

            SelectedTeamIsVisible = true;
            AddTeamIsVisible = false;
        }

        public void Handle(PrizeModel message)
        {
            if (!String.IsNullOrWhiteSpace(message.PlaceName))
            {
                SelectedPrizes.Add(message);
            }

            SelectedPrizeIsVisible = true;
            AddPrizeIsVisible = false;
        }
    }
}
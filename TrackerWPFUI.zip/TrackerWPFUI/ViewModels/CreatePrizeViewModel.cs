﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TrackerWPFUI.ViewModels
{
    public class CreatePrizeViewModel : Screen
    {
        /// <summary>
        /// Private Variables
        /// </summary>
        private int _PlaceNumber;
        private string _PlaceName;
        private double _PrizeAmount;
        private double _PrizePercentage;


        public int PlaceNumber
        {
            get { return _PlaceNumber; }

            set
            { 
                _PlaceNumber = value;
                NotifyOfPropertyChange(() => PlaceNumber);
            }
        }

        public string PlaceName
        {
            get { return _PlaceName; }
            set 
            { 
                _PlaceName = value; 
                NotifyOfPropertyChange(() => PlaceName);
            }
        }

        public double PrizeAmount
        {
            get { return _PrizeAmount; }
            set
            { 
                _PrizeAmount = value;
                NotifyOfPropertyChange(() => PrizeAmount);
            }
        }

        public double PrizePercentage
        {
            get { return _PrizePercentage; }
            set 
            { 
                _PrizePercentage = value;
                NotifyOfPropertyChange(() => PrizePercentage);
            }
        }

        public void CancelCreation()
        {
            EventAggregationProvider.TournamentTrackerEventAggregator.PublishOnCurrentThread(new PrizeModel());
            this.TryClose();
        }


        public bool CanCreatePrize(int PlaceNumber,
            string PlaceName, decimal PrizeAmount, double PrizePercentage)
        {
            return ValidateForm(PlaceNumber, PlaceName, PrizeAmount, PrizePercentage);
        }

        public void CreatePrize(int PlaceNumber,
            string PlaceName, decimal PrizeAmount, double PrizePercentage)
        {
            PrizeModel p = new PrizeModel
            {
                placeNumber = PlaceNumber,
                PlaceName = PlaceName,
                prizeAmount = PrizeAmount,
                prizePercentage = PrizePercentage
            };

            GlobalConfig.Connection.CreatePrize(p);

            EventAggregationProvider.TournamentTrackerEventAggregator.PublishOnCurrentThread(p);
            this.TryClose();
        }

        private bool ValidateForm(int PlaceNumber,string PlaceName, decimal PrizeAmount, double PrizePercentage)
        {
            bool output = true;

            if (PlaceNumber < 1)
            {
                output = false;
            }

            if (PlaceName.Length == 0)
            {
                output = false;
            }

            if (PrizeAmount <= 0 && PrizePercentage <= 0)
            {
                output = false;
            }

            if (PrizePercentage < 0 || PrizePercentage > 100)
            {
                output = false;
            }
            return output;
        }
    }
}

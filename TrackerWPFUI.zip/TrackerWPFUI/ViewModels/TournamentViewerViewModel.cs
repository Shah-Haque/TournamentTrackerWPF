﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TrackerWPFUI.ViewModels
{
    //52:35
    public class TournamentViewerViewModel : Screen
    {
        public TournamentModel Tournament { get; set; }

        private string _TournamentName;
        private BindableCollection<int> _Rounds = new BindableCollection<int>();
        private BindableCollection<MatchupModel> _Matchups = new BindableCollection<MatchupModel>();
        private bool _UnplayedOnly;
        private string _TeamOne;
        private string _TeamTwo;
        private double _TeamOneScore;
        private double _TeamTwoScore;
        private MatchupModel _SelectedMatchup;
        private int _SelectedRound = 0;

        public TournamentViewerViewModel(TournamentModel tournament)
        {
            Tournament = tournament;
            TournamentName = tournament.TournamentName;

            LoadRounds();
        }

        public string TournamentName
        {
            get
            {
                return $"Tournament: {_TournamentName}";
            }
            set
            {
                _TournamentName = value;
                NotifyOfPropertyChange(() => TournamentName);
            }
        }

        public BindableCollection<int> Rounds
        {
            get { return _Rounds; }
            set { _Rounds = value; }
        }

        public BindableCollection<MatchupModel> Matchups
        {
            get { return _Matchups; }
            set { _Matchups = value; }
        }

        public bool UnplayedOnly
        {
            get { return _UnplayedOnly; }
            set
            {
                _UnplayedOnly = value;
                NotifyOfPropertyChange(() => UnplayedOnly);
                LoadMatchups();
            }
        }

        public string TeamOne
        {
            get { return _TeamOne; }
            set
            {
                _TeamOne = value;
                NotifyOfPropertyChange(() => TeamOne);
            }
        }

        public string TeamTwo
        {
            get { return _TeamTwo; }
            set
            {
                _TeamTwo = value;
                NotifyOfPropertyChange(() => TeamTwo);
            }
        }

        public double TeamOneScore
        {
            get { return _TeamOneScore; }
            set
            {
                _TeamOneScore = value;
                NotifyOfPropertyChange(() => TeamOneScore);
            }
        }

        public double TeamTwoScore
        {
            get { return _TeamTwoScore; }
            set
            {
                _TeamTwoScore = value;
                NotifyOfPropertyChange(() => TeamTwoScore);
            }
        }

        public MatchupModel SelectedMatchup
        {
            get { return _SelectedMatchup; }
            set
            {
                _SelectedMatchup = value;
                NotifyOfPropertyChange(() => SelectedMatchup);
                LoadMatchup();
            }
        }

        public int SelectedRound
        {
            get { return _SelectedRound; }
            set
            {
                _SelectedRound = value;
                NotifyOfPropertyChange(() => SelectedRound);
                LoadMatchups();
            }
        }

        private void LoadRounds()
        {
            Rounds.Clear();

            Rounds.Add(1);
            int currRound = 1;

            foreach (List<MatchupModel> matchups in Tournament.Rounds)
            {
                if (matchups.First().MatchupRound > currRound)
                {
                    currRound = matchups.First().MatchupRound;
                    Rounds.Add(currRound);
                }
            }
            SelectedRound = 1;
        }

        private void LoadMatchups()
        {
            foreach (List<MatchupModel> matchups in Tournament.Rounds)
            {
                if (matchups.First().MatchupRound == SelectedRound)
                {
                    Matchups.Clear();
                    foreach (MatchupModel m in matchups)
                    {
                        if (m.Winner == null || !UnplayedOnly)
                        {
                            Matchups.Add(m);
                        }
                    }
                }
            }

            if (Matchups.Count > 0)
            {
                SelectedMatchup = Matchups.First();
            }
        }

        private void LoadMatchup()
        {
            if (SelectedMatchup == null)
            {
                return;
            }
            for (int i = 0; i < SelectedMatchup.Entries.Count; i++)
            {
                if (i == 0)
                {
                    if (SelectedMatchup.Entries[0].TeamCompeting != null)
                    {
                        TeamOne = SelectedMatchup.Entries[0].TeamCompeting.TeamName;
                        TeamOneScore = SelectedMatchup.Entries[0].Score;

                        TeamTwo = "<bye>";
                        TeamTwoScore = 0;
                    }
                    else
                    {
                        TeamOne = "Not Yet Set";
                        TeamOneScore = 0;
                    }
                }

                if (i == 1)
                {
                    if (SelectedMatchup.Entries[1].TeamCompeting != null)
                    {
                        TeamTwo = SelectedMatchup.Entries[1].TeamCompeting.TeamName;
                        TeamTwoScore = SelectedMatchup.Entries[1].Score;
                    }
                    else
                    {
                        TeamTwo = "Not Yet Set";
                        TeamTwoScore = 0;
                    }
                }
            }
        }
        public void ScoreMatch()
        {
            for (int i = 0; i < SelectedMatchup.Entries.Count; i++)
            {
                if (i == 0)
                {
                    if (SelectedMatchup.Entries[0].TeamCompeting != null)
                    {
                        SelectedMatchup.Entries[0].Score = TeamOneScore;
                    }
                }

                if (i == 1)
                {
                    if (SelectedMatchup.Entries[1].TeamCompeting != null)
                    {
                        SelectedMatchup.Entries[1].Score = TeamTwoScore;
                    }
                }
            }

            try
            {
                TournamentLogic.UpdateTournamentResults(Tournament);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"The application had the following error: {ex.Message}");
                return;
            }

            LoadMatchups();
        }
    }
}
﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrackerLibrary.Models;
using TrackerLibrary;

namespace TrackerWPFUI.ViewModels
{
    public class CreatePersonViewModel : Screen
    {
        /// <summary>
        /// variables
        /// </summary>
		private string _FirstName = "";
        private string _LastName = "";
        private string _TelephoneNumber = "";
        private string _EmailAddress = "";

        public string FirstName
        {
            get { return _FirstName; }
            set
            {
                _FirstName = value;
                NotifyOfPropertyChange(() => FirstName);
            }
        }

        public string LastName
        {
            get { return _LastName; }
            set
            {
                _LastName = value;
                NotifyOfPropertyChange(() => LastName);
            }
        }

        public string EmailAddress
        {
            get { return _EmailAddress; }
            set
            {
                _EmailAddress = value;
                NotifyOfPropertyChange(() => EmailAddress);
            }
        }

        public string TelephoneNumber
        {
            get { return _TelephoneNumber; }
            set
            {
                _TelephoneNumber = value;
                NotifyOfPropertyChange(() => TelephoneNumber);
            }
        }

        public void CancelCreation()
        {
            EventAggregationProvider.TournamentTrackerEventAggregator.PublishOnCurrentThread(new PersonModel());
            this.TryClose();
        }

        public bool CanCreatePerson(string FirstName, 
            string LastName, string EmailAddress, string TelephoneNumber)
        {
            if (FirstName.Length > 0 
                && LastName.Length > 0 
                && EmailAddress.Length > 0 
                && TelephoneNumber.Length > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void CreatePerson(string FirstName, 
            string LastName, string EmailAddress, string TelephoneNumber)
        {
            PersonModel p = new PersonModel();

            p.FirstName = FirstName;
            p.LastName = LastName;
            p.EmailAddress = EmailAddress;
            p.TelephoneNumber = TelephoneNumber;

            GlobalConfig.Connection.CreatePerson(p);
            
            EventAggregationProvider.TournamentTrackerEventAggregator.PublishOnCurrentThread(p);
            this.TryClose();
        }
    }
}